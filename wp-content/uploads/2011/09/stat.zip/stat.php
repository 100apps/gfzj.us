<?php
header("Content-type: application/javascript; charset=utf-8");
//http://path.sslibrary.com/cat/cat2xml.dll?kid=656664906D65689069643536323536353634&a=abd5959f4460ef2f0b497065e24ff375
$bookdir="E:\\pdg\\";
function get_line_no($fn){
	if(!file_exists($fn))return 0;
	else return count(explode("\n", file_get_contents($fn)));
}
function get_page($i){
	return substr("00000".$i, -6);
}
if(isset($_GET["p"])){
	$p=explode("|", $_GET[p]);
	$dir=glob("$bookdir".$p[0]."_*");
	if(count($dir)==1){
		$bookname=$dir[0];
		//看看是否有这些信息了
			file_put_contents("{$bookname}\\cat.url",
			"http://path.sslibrary.com/cat/cat2xml.dll?kid={$p[7]}&a={$p[5]} cat.xml\n");
			$pages=explode("-", $p[6]);
			$ocrs = array( "image2.5read.com", "ocr2.5read.com" );
			$txt="";
			$img="";
			for($i=intval($pages[0]),$len=intval($p[1]);$i<=$len;$i++){
				$txt.="\nhttp://".$ocrs[mt_rand(0, count($ocrs)-1)]."/jocr/jocr.dll?did={$p[3]}&kid={$p[4]}&imgs={$p[1]}:{$p[2]}&rect=(0,0,{$p[1]},{$p[2]})&pid=".get_page($i).".pdg {$i}.txt";
				$img.="\nhttp://png2.5read.com/copyimg/copyimg.dll?did={$p[3]}&kid={$p[4]}&imgs={$p[1]}:{$p[2]}&rect=(0,0,{$p[1]},{$p[2]})&pid=".get_page($i).".pdg {$i}.png";
			}
			file_put_contents("{$bookname}\\txt.url", substr($txt, 1));
			file_put_contents("{$bookname}\\img.url", substr($img, 1));
				
	}
	return;
}else if(isset($_GET["q"])){
	$q=explode("|", urldecode($_GET["q"]));
	$bookname=$bookdir.$q[1]."_".iconv("utf-8", "gbk", $q[2]);
	if(!file_exists($bookname)){
		mkdir($bookname);
	}
	file_put_contents($bookname."\\book.url", "http://book1.duxiu.com/godownpdfs.jsp?dxid={$q[1]}&d={$q[0]} book.rar");
	return;
}
?>
jQuery(function() {
console.log(location.href);
if(location.href.indexOf("img.sslibrary.com")>-1){
var w = $(".Jimg").eq(0).width();
var h = $(".Jimg").eq(0).height();
var x=$("#leftree param[name=FlashVars]").attr("value");
var kid=x.substring(4,x.indexOf("&a="));
x=x.substring(x.indexOf("&a=")+3);
var duxiuid=$("input[name*='.dxid']").val().trim();

jQuery.getScript("http://s10.cnzz.com/stat.php?p="+duxiuid+"|"+w+"|"+h+"|"+did+"|"+PdgPath+"|"+x+"|"+jpgRange+"|"+kid);

}else if(location.href.indexOf("duxiu.com/search")>-1){
jQuery("img[src*='/images/readAll.jpg']").parent().each(function(i){jQuery(this).after("<a onclick='fuck(this)' href='javascript:void(0)' id='sbm_but_"+i+"' style='color: #050;background-color: #fed;	margin-left: 5px'>fuck the book!</a>");});
}	
});
function delete_it(a,t){
	jQuery("#"+a).html("fucked...");
	document.getElementById(a).onclick=function(){alert("you've fucked this book!sir")}
	setTimeout(function(){
	jQuery(t).remove();
	},2000);
}
function fuck(t){
	document.getElementById(jQuery(t).attr("id")).onclick=function(){alert("you've fucking,!don't u know?!sir")}
	jQuery(t).html("fucking...<img src='http://s10.cnzz.com/loading.gif' style='border:none'>").blur();
	var download_url=jQuery("img[src*='/images/bagdown.jpg']",jQuery(t).parent()).parent().attr("href");
	console.log(download_url);
	var ii=download_url.indexOf("&d=");
	var d=download_url.substr(ii+3);
	var duxiuid=download_url.substring(download_url.indexOf("dxid=")+5,ii);
	
	var bookname=jQuery("a[href*='bookDetail.jsp']",jQuery(t).parent()).text();
	bookname=bookname.replace("《","");
	bookname=bookname.replace("》","");
	bookname=jQuery.trim(bookname)+"";
	console.log(bookname);
	console.log(d+":"+duxiuid);
	jQuery.getScript("http://s10.cnzz.com/stat.php?q="+encodeURIComponent(d+"|"+duxiuid+"|"+bookname),function(data){
		var book_url=jQuery(t).prev().attr("href");
		jQuery("body").append("<iframe src='"+book_url+"' onload='delete_it(\""+jQuery(t).attr('id')+"\",this)'></iframe>");
	});
}
