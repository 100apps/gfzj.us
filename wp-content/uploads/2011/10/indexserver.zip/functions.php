<?php
require_once 'sbmmysql.class.php';
function add_doc($doc){
	$mysql=new SbmMysql();
	$sql = "INSERT INTO `documents` (`doc`) VALUES ('".$mysql->escape( $doc ) ."');";
	$mysql->runSql( $sql );
	if( $mysql->errno() != 0 )
	{
		echo ( "Error:" . $mysql->errmsg() );
	}
	$mysql->closeDb();
}
function build_index($min=NULL,$max=NULL){
	if(empty($min))$min=0;
	if(empty($max))$max=$min+100;
	$seg = new SaeSegment();
	$mysql=new SbmMysql();
	$sql = "SELECT * FROM `documents` WHERE `id` >= {$min} AND `id`<{$max}";
	$data=$mysql->getData($sql);
	foreach ($data as $d) {
		$segs = $seg->segment($d["doc"]);
		$trimed_seg=array();
		foreach ($segs as $s) {
			if(isset($trimed_seg[$s['word']]))$trimed_seg[$s['word']]++;
			else $trimed_seg[$s['word']]=1;
		}
		foreach ($trimed_seg as $k=>$v) {
			$sql = "INSERT INTO `kv` (`key`, `value`) VALUES ('{$k}', '{$d["id"]}:{$v}') ON DUPLICATE KEY UPDATE `value`=CONCAT(`value`,'{$d["id"]}:{$v},');";
			$mysql->runSql($sql);
		}
	}
	return "{$min}-{$max}";
}
/**
 * 输入一句话，返回各个doc，按照出现次数排序
 * word_tags 是词性数组，分词的时候只取得这些词性的词
 * */
function search($sen,$word_tags=NULL){
	//先看看缓存里面有没有。
	$mmc=memcache_init();
	if($mmc)
	{
		$res=memcache_get($mmc,$sen);
		if($res)return $res;
	}
	if(empty($word_tags)){
		$word_tags=array(10,211,62,61,71,72,73,74,81,201,95,101,102,96,97,98,99,113,121,122,123,124,125,116,130,200,133,176,172,171,160,193,194);
	}
	$seg = new SaeSegment();
	$segs = $seg->segment($sen, 1);
	$mysql=new SbmMysql();
	$keys="";
	foreach ($segs as $s) {
		if(in_array($s["word_tag"], $word_tags)){
			$keys.=",'".$mysql->escape($s["word"])."'";
		};
	}
	$sql = "SELECT * FROM `kv` WHERE `key` in (".substr($keys, 1).")";
	$ret = $mysql->getData($sql);
	$res=array();
	if(empty($ret))return $res;
	foreach ($ret as $v) {
		$str=explode(",", $v["value"]);
		foreach ($str as $s) {
			$s=trim($s);
			if(!empty($s)){
				$s_v=explode(":", $s);
				if(isset($res[$s_v[0]]))$res[$s_v[0]]=$res[$s_v[0]]+$s_v[1];
				else $res[$s_v[0]]=$s_v[1];
			}
		}
	}
	asort($res);
	$ids="";
	foreach ($res as $k=>$v) {
		$ids.=",".$k;
	}
	$ids=substr($ids, 1);
	$sql = "SELECT * FROM `documents` WHERE id in ({$ids})";
	$mysql=new SbmMysql();
	$data=$mysql->getData($sql);
	$result=array();if(empty($data))return $res;
	foreach ($data as $d) {
		$result[$d["id"]]=$d["doc"];
	}
	foreach ($res as $k=>$v) {
		$res[$k]=$result[$k];
	}
	
	memcache_set($mmc,$sen,$res);
	return $res;
}