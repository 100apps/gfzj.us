<?php
require_once 'functions.php';
if(isset($_GET["cmd"])){
	switch ($_GET["cmd"]) {
		case "add":
			add_doc($_POST["doc"]);
			echo "ok";
			break;
		case "build":
			echo build_index($_GET["sid"])."\n";
			break;
		case "kv":
			$kv = new SaeKVClient();
			$ret = $kv->init();
			var_dump($kv->get_info());
			// 循环获取所有key-values
			$kv->set("aaaaaa","测试用");
// 			var_dump($kv->get("aaaaaa"));
// 			var_dump( $kv->get("k"));
			var_dump( $kv->get("是"));
			$ret = $kv->pkrget(EMPTY_PREFIXKEY, 100);
			var_dump($ret);
			break;
		default:
			;
			break;
	}
}
if(isset($_GET["api"]))return;
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<style>
#kw{
	width:444px;
	border-color: #9A9A9A #CDCDCD #CDCDCD #9A9A9A;
    border-style: solid;
    border-width: 1px;
    font: 16px arial;
    height: 22px;
    padding: 4px 7px;
    vertical-align: top;
    margin: 0 5px 0 0;
}
#btn {
    background: url("http://su.bdimg.com/static/superpage/img/spis_3793e12d.png") repeat scroll 0 -35px #DDDDDD;
    border: 0 none;
    cursor: pointer;
    height: 32px;
    padding: 0;
    width: 95px;
}
</style>
<title><?php if(isset($_GET["s"]))echo $_GET["s"]." - "?>基于sinaapp的全文搜索引擎</title>
</head>
<body>
<form action="/"><input maxlength="100" autocomplete="off" name="s" id="kw" value="<?php echo $_GET["s"]?>"><input type="submit" id='btn' value="搜索一下"></form>
<?php 
if(!empty($_GET["s"])){
	$st=microtime(true);
	$res=search($_GET["s"]);
	echo "<h3>共找到".count($res)."个相关文档。用时:".(microtime(true)-$st)."秒</h3><hr>";
	
	foreach ($res as $v) {
		echo "<p>{$v}</p>";
	}
}
?>
</body>
</html>
