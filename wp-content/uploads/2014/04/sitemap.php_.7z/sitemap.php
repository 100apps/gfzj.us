<?php
$excludes=array(339);//哪些文章不需要 
$excludeClass=array(5,4);//哪些分类不需要
$filename="sitemap.xml";//写入到哪个文件。

require('e/class/connect.php');
require('e/class/db_sql.php');
require('e/data/dbcache/class.php');
$link=db_connect();
$empire=new mysqlquery();

//------- 插件参数设置开始 -----

//只显示栏目最新几条信息，0为全部显示
$shownum=0;

//------- 插件参数设置结束 -----


header("Content-type: text/html");

//取得网站地址
$siteurl=$public_r['newsurl'];
if(!stristr($public_r['newsurl'],'://'))
{
	$siteurl=eReturnDomain().$public_r['newsurl'];
}
$siteurl=substr($siteurl,0,-1);//网站域名
$siteurl=str_replace("//local.","//www.",$siteurl);
if(empty($siteurl))
	$siteurl="http://www.".substr(__DIR__,strrpos(__DIR__,'/')+1);

$ret='<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';

$classids=array();
//if(empty($classid))//栏目导航
{
	$sql=$empire->query("SELECT classid,classpath FROM {$dbtbpre}enewsclass WHERE islast=1");
	while($r=$empire->fetch($sql))
	{
		if(in_array($r["classid"],$excludeClass))continue;
		$classids[]=$r["classid"];
		$infor=$empire->fetch1("SELECT newstime FROM {$dbtbpre}ecms_".$class_r[$r[classid]][tbname]." WHERE classid='$r[classid]' ORDER BY newstime DESC LIMIT 1");
$ret.="<url><loc>{$siteurl}{$public_r['newsurl']}{$r["classpath"]}/</loc><lastmod>".date('Y-m-d',$infor[newstime])."</lastmod><changefreq>daily</changefreq><priority>0.5</priority></url>\n";
        }
}
//else//信息列表

foreach($classids as $classid)
{
	$limit=$shownum?' order by newstime desc limit '.$shownum:'';
	$sql=$empire->query("SELECT id,classid,isurl,titleurl,newstime FROM {$dbtbpre}ecms_".$class_r[$classid][tbname]." WHERE classid='$classid'".$limit);
	while($r=$empire->fetch($sql))
	{
		if(in_array($r["id"],$excludes))continue;
		if($r['isurl'])
		{
			continue;
		}
		$titleurl=sys_ReturnBqTitleLink($r);
		$titleurl=str_replace('&','&amp;',$titleurl);
		if(!stristr($titleurl,'://'))
		{
			if($public_r['newsurl']=='/')
			{
				$titleurl=$siteurl.$titleurl;
			}
			else
			{
				$titleurl=str_replace($public_r['newsurl'],$siteurl,$titleurl);
			}
		}
		$ret.="<url><loc>{$titleurl}</loc><lastmod>".date('Y-m-d',$r[newstime])."</lastmod><changefreq>daily</changefreq><priority>0.5</priority></url>\n";
	}
}

db_close();
$empire=null;
$ret.="</urlset>";
file_put_contents($filename,$ret);
echo "done!";
?>
