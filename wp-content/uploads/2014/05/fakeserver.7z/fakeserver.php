<?php
$fn="fakeserver.log";
if(PHP_SAPI == 'cli'){
	$log=array();
	if (($handle = fopen($fn, "r")) !== FALSE) {
		while (($data = fgetcsv($handle, 0, "\t")) !== FALSE) $log[]=$data;
		fclose($handle);
	}
	$name=array("时间");
	foreach (array("时间"=>0,"IP"=>1,"域名"=>3,"路径"=>4,"useragent"=>5) as $name=>$i){
		if($i==0){
			$min=PHP_INT_MAX;$max=0;$count=0;
			foreach ($log as $line){
				$v=intval($line[0]);
				if($v<$min)$min=$v;
				if($v>$max)$max=$v;
				$count++;
			}
			echo "\n\n#".$name."\n\n";
			echo "在 ".($max-$min)." 秒时间内，共有 ".$count." 次请求.\n";
			continue;
		}
		$result=array();
		$kv=array();
		foreach ($log as $line){
			$result[$line[$i]]=isset($result[$line[$i]])?$result[$line[$i]]+1:1;
			$kv[$line[$i]]=implode("\t", $line);
		}
		arsort($result,SORT_NUMERIC);
		echo "\n\n#".$name."\n\n";
		$count=0;
		foreach ($result as $k=>$v){
			if($count++>10)break;
			echo $v."\t".$kv[$k]."\n";
		}
	}
	//var_dump($log);
	die("ok");
}
/*创造一个假的服务器，用来统计谁在访问服务器。*/
$log=$_SERVER["REQUEST_TIME"]."\t".$_SERVER["REMOTE_ADDR"]."\t".$_SERVER["REMOTE_PORT"]."\t".$_SERVER["HTTP_HOST"]."\t".$_SERVER["REQUEST_URI"]."\t".$_SERVER["HTTP_USER_AGENT"]."\n";
file_put_contents($fn, $log,FILE_APPEND| LOCK_EX );
//return 503
$protocol = "HTTP/1.0";
if ( "HTTP/1.1" == $_SERVER["SERVER_PROTOCOL"] )
	$protocol = "HTTP/1.1";
header( "$protocol 503 Service Unavailable", true, 503 );
header( "Retry-After: 3600" );
die("<h1>503 Service Unavailable</h1>");